// backend/services/socketService.js
const Message = require("../models/Message");

module.exports = function (io) {
  io.on("connection", (socket) => {
    console.log("🟢 New client connected:", socket.id);

    // Join a chat room
    socket.on("joinRoom", ({ chatRoomId }) => {
      socket.join(chatRoomId);
      console.log(`Socket ${socket.id} joined room ${chatRoomId}`);
    });

    // Receive and broadcast a message
    socket.on("sendMessage", async ({ chatRoomId, senderId, message }) => {
      // Save to MongoDB
      const newMessage = new Message({ chatRoomId, sender: senderId, message });
      await newMessage.save();

      // Broadcast to room
      io.to(chatRoomId).emit("receiveMessage", {
        senderId,
        message,
        timestamp: newMessage.timestamp,
      });
    });

    socket.on("disconnect", () => {
      console.log("🔴 Client disconnected:", socket.id);
    });
  });
};
