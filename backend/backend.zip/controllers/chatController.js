const Message = require("../models/Message");

const getChatHistory = async (req, res) => {
	try {
		const { charRoomId } = req.params;

		const messages = await Message.find({ chatRoomId }).sort({ timestamp: 1 }).populate("sender", "name role");

		res.status(200).json(messages);
	} catch (error) {
		console.log("Error fetching the chat history: ", error);
		res.status(500).json({ error: "Failed to load messages" });
	}
};

module.exports = { getChatHistory };
